# Architecture Drift Radar - illustrative deterministic starter

**Not production-ready.** This package demonstrates how to evaluate architecture facts against a protected policy and how deliberately unsafe changes fail. It does not parse Java, verify CI run provenance, authenticate approvals, attest artifacts, or enforce GitHub branch rules on its own.

## Quick test

```bash
pip install pyyaml
python -m unittest discover -s tests -v
python architecture_guard.py --policy architecture-policy.yml \
  --baseline fixtures/baseline.json \
  --candidate fixtures/candidate_fail.json \
  --evidence fixtures/evidence_pass.json \
  --head-sha example-commit-123 --output drift-report.json
```

This last invocation exits 1 because the example contains deliberately forbidden changes; the PASS candidate exits 0.

## Architecture evidence and trust boundary

- Build service-capability inventory from reviewed ownership tags and architecture decision records (ADRs).
- Extract class/package edges with ArchUnit, service/message edges from Kafka/CQ configuration, API/client references, and topic/schema registries. Detect dynamic/reflection-based traffic with runtime telemetry and declare coverage gaps. The `extraction_complete` flag should be set only by the trusted extractor.
- Compare an approved baseline (protected branch and policy revision) against the merge candidate (and merged queue SHA if used). Do not accept a baseline that a PR can overwrite.
- Retrieve RC test suites and passed status from **independent GitHub CI runs** tied to exact SHA; do not accept PR-authored evidence JSON.
- Distinguish structural **BLOCK** from semantic **REVIEW**. Review warnings do not automatically establish correct architecture.
- Protect policy edits, exception approvals, and the verifier with CODEOWNERS/required workflows; request authorised, time-limited human approval for high-risk architecture changes. In production, centrally controlled CI is responsible for checking real approval state and blocking unresolved reviews.
- Because service and channel names here are invented examples for illustration, confirm all mappings with your architecture team before use.

## Example candidate

The failing fixture deliberately relocates FSM capability, introduces unapproved edges and a cycle, publishes a protected message from an unauthorised service, and writes another service's data store. The evaluator produces rule-linked findings with remediation cues.
