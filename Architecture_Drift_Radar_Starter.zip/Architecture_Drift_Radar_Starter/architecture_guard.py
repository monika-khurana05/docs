#!/usr/bin/env python3
"""Illustrative, deterministic architecture facts evaluator.

Input architecture facts must be extracted independently by trusted CI from
compiled classes, repository configs, APIs and schemas. Never treat an agent-
authored facts JSON or evidence JSON as authoritative proof in production.
"""
import argparse
import json
from collections import defaultdict
from pathlib import Path
import sys
import yaml


def edge_key(edge):
    return (edge['source'], edge['target'], edge['kind'], edge.get('channel', ''))


def cyclic_components(edges):
    graph = defaultdict(set)
    for item in edges:
        graph[item['source']].add(item['target'])
    state = {}
    stack = []
    cycles = []
    def dfs(node):
        state[node] = 1
        stack.append(node)
        for nxt in sorted(graph.get(node, [])):
            if state.get(nxt, 0) == 1:
                cycles.append(stack[stack.index(nxt):] + [nxt])
            elif state.get(nxt, 0) == 0:
                dfs(nxt)
        stack.pop()
        state[node] = 2
    for node in sorted(set(graph) | set().union(*graph.values()) if graph else set()):
        if state.get(node, 0) == 0:
            dfs(node)
    return cycles


def evaluate(policy, baseline, candidate, evidence, expected_sha):
    blockers = []
    warnings = []
    def block(rule, reason, location='', remediation=''):
        blockers.append({'rule':rule,'reason':reason,'location':location,'remediation':remediation})
    def warn(rule, reason, location=''):
        warnings.append({'rule':rule,'reason':reason,'location':location})
    if policy.get('schema_version') != 1:
        block('ADR-00','Unsupported or missing policy schema_version')
    if policy.get('require_complete_extraction') and not candidate.get('extraction_complete', False):
        block('ADR-00','Architecture extraction incomplete or unknown; do not accept empty graph as clean')
    if evidence.get('head_sha') != expected_sha or not evidence.get('trusted_run'):
        block('ADR-00','Evidence is not bound to expected SHA or not marked trusted; CI must validate run authenticity')

    # ADR-01: capability ownership - only robust when facts are well-tagged.
    owners = policy.get('capability_owners', {})
    seen = defaultdict(set)
    for cap in candidate.get('capabilities', []):
        name, svc = cap['capability'], cap['service']
        seen[name].add(svc)
        if name in owners and owners[name] != svc:
            block('ADR-01',f'{name} belongs to {owners[name]}, not {svc}',cap.get('file',''), 'Move logic to owning service or obtain approved change to architecture contract')
        elif name not in owners:
            warn('ADR-01',f'Unknown capability tag: {name}',cap.get('file',''))
    for cap, services in seen.items():
        if len(services) > 1:
            block('ADR-11',f'{cap} implemented in multiple services: {sorted(services)}')

    # ADR-02/05/08: compare graph with approved policy and existing baseline.
    base_edges = {edge_key(x) for x in baseline.get('edges', [])}
    allowed = {edge_key(x) for x in policy.get('allowed_edges', [])}
    current_edges = {edge_key(x) for x in candidate.get('edges', [])}
    for edge in candidate.get('edges', []):
        key = edge_key(edge)
        if key not in base_edges and key not in allowed:
            block('ADR-02',f'New edge not allowlisted: {key}',edge.get('file',''), 'Request architecture approval and edit governed allowlist')
        if key not in base_edges and edge['kind'] == 'internal_api' and edge['source'] != edge['target']:
            block('ADR-05',f'New cross-service use of private APIs: {key}',edge.get('file',''))
        if key not in base_edges and edge['kind'] in ('rest','grpc') and edge['source'] in policy.get('no_new_sync_outbound_from', []):
            block('ADR-08',f'New synchronous call from latency-sensitive service: {key}',edge.get('file',''))
    old_cycles = {tuple(x) for x in cyclic_components(baseline.get('edges', []))}
    for cycle in cyclic_components(candidate.get('edges', [])):
        if tuple(cycle) not in old_cycles:
            block('ADR-04',f'New service-level dependency cycle: {" -> ".join(cycle)}')

    # ADR-03: publisher/consumer identity from extracted wiring, not authored metadata.
    for access in candidate.get('channel_access', []):
        channel = access['channel']; p = policy.get('protected_channels', {}).get(channel)
        if p is None:
            warn('ADR-03',f'Unregistered channel {channel}; classification required',access.get('file',''))
            continue
        valid = p.get('publishers',[]) if access['role'] == 'publish' else p.get('consumers',[])
        if access['service'] not in valid:
            block('ADR-03',f'Unauthorized {access["role"]} on {channel}: {access["service"]}',access.get('file',''))

    # ADR-06: data ownership; writes across service ownership block even if not new.
    for access in candidate.get('data_access', []):
        if access['operation'] not in ('write','update','delete'): continue
        store=access['store']; p=policy.get('protected_stores',{}).get(store)
        if p is None:
            warn('ADR-06',f'Write to unregistered store {store}; ownership needed',access.get('file',''))
        elif access['service'] not in p.get('write_owners',[]):
            block('ADR-06',f'{access["service"]} may not write store {store}',access.get('file',''))

    # ADR-07/09: protected changes require mapped RC suites; proof must be CI-verified.
    suite_map=policy.get('required_suites_by_change_kind',{})
    suites=set(evidence.get('passed_suites',[]))
    for change in candidate.get('changed_artifacts', []):
        kind=change['kind']
        if kind not in suite_map:
            warn('ADR-07',f'Unmapped changed artifact kind {kind}; require policy triage',change.get('file',''))
        for suite in suite_map.get(kind,[]):
            if suite not in suites:
                block('ADR-07',f'{kind} requires passing trusted suite {suite}',change.get('file',''))
    for x in candidate.get('semantic_warnings',[]):
        warn('ADR-10',x.get('reason','Semantic drift flagged for review'),x.get('file',''))
    return {'verdict':'BLOCK' if blockers else 'REVIEW' if warnings else 'PASS',
            'policy_id':policy.get('policy_id'),
            'blockers':blockers,'warnings':warnings,
            'new_edges':[list(x) for x in sorted(current_edges-base_edges)],
            'removed_edges':[list(x) for x in sorted(base_edges-current_edges)],
            'note':'Illustrative evaluator; production evidence and fact extraction must be trusted and independently verified.'}


def main():
    cli=argparse.ArgumentParser()
    cli.add_argument('--policy',required=True)
    cli.add_argument('--baseline',required=True)
    cli.add_argument('--candidate',required=True)
    cli.add_argument('--evidence',required=True)
    cli.add_argument('--head-sha',required=True)
    cli.add_argument('--output',default='')
    args=cli.parse_args()
    try:
        policy=yaml.safe_load(Path(args.policy).read_text())
        baseline=json.loads(Path(args.baseline).read_text())
        candidate=json.loads(Path(args.candidate).read_text())
        evidence=json.loads(Path(args.evidence).read_text())
        report=evaluate(policy,baseline,candidate,evidence,args.head_sha)
        body=json.dumps(report,indent=2)
        print(body)
        if args.output: Path(args.output).write_text(body+'\n')
        return 1 if report['blockers'] else 0
    except (OSError,KeyError,ValueError,TypeError,yaml.YAMLError) as exc:
        print(f'architecture guard input or evaluation error: {exc}',file=sys.stderr)
        return 2

if __name__=='__main__': sys.exit(main())
