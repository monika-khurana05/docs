import json
import unittest
from pathlib import Path
import yaml
from architecture_guard import evaluate

ROOT=Path(__file__).resolve().parents[1]
class GuardTests(unittest.TestCase):
    def setUp(self):
        self.policy=yaml.safe_load((ROOT/'architecture-policy.yml').read_text())
        self.base=json.loads((ROOT/'fixtures/baseline.json').read_text())
        self.evidence=json.loads((ROOT/'fixtures/evidence_pass.json').read_text())
    def test_safe_candidate_passes(self):
        passed=json.loads((ROOT/'fixtures/candidate_pass.json').read_text())
        self.assertEqual(evaluate(self.policy,self.base,passed,self.evidence,'example-commit-123')['verdict'],'PASS')
    def test_unsafe_candidate_blocks(self):
        bad=json.loads((ROOT/'fixtures/candidate_fail.json').read_text())
        result=evaluate(self.policy,self.base,bad,self.evidence,'example-commit-123')
        rules={x['rule'] for x in result['blockers']}
        self.assertTrue({'ADR-01','ADR-02','ADR-03','ADR-04','ADR-06'} <= rules)
    def test_missing_required_rc_evidence_blocks(self):
        bad=json.loads((ROOT/'fixtures/candidate_fail.json').read_text())
        empty=json.loads((ROOT/'fixtures/evidence_fail.json').read_text())
        result=evaluate(self.policy,self.base,bad,empty,'example-commit-123')
        self.assertIn('ADR-07',{x['rule'] for x in result['blockers']})
    def test_stale_sha_blocks(self):
        candidate=json.loads((ROOT/'fixtures/candidate_pass.json').read_text())
        result=evaluate(self.policy,self.base,candidate,self.evidence,'different-SHA')
        self.assertEqual(result['verdict'],'BLOCK')
    def test_incomplete_extraction_blocks(self):
        candidate=json.loads((ROOT/'fixtures/candidate_pass.json').read_text());candidate['extraction_complete']=False
        result=evaluate(self.policy,self.base,candidate,self.evidence,'example-commit-123')
        self.assertEqual(result['verdict'],'BLOCK')

if __name__=='__main__': unittest.main()
